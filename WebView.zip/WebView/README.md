WebView

Simple WebView Android Kotlin
You can change your URL at java/WebViewActivity.kt
